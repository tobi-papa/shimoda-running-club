// App root — glues sections together

function App() {
  const tweaks = useTweaks(/*EDITMODE-BEGIN*/{
    "accent": "rainbow",
    "grain": true,
    "cardStyle": "solid-shadow"
  }/*EDITMODE-END*/);

  const [upcoming, setUpcoming] = React.useState(SEED_UPCOMING);
  const [past, setPast] = React.useState(SEED_PAST);
  const [createOpen, setCreateOpen] = React.useState(false);
  const [joinEvent, setJoinEvent] = React.useState(null);

  // reveal-on-scroll observer
  React.useEffect(() => {
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => { if (e.isIntersecting) e.target.classList.add("in"); });
    }, { threshold: 0.12 });
    document.querySelectorAll(".reveal").forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, [upcoming, past]);

  const addEvent = (ev) => setUpcoming([...upcoming, ev].sort((a, b) => new Date(a.run_at) - new Date(b.run_at)));
  const joinRun = (id, names) => setUpcoming(upcoming.map(e => e.id === id ? { ...e, participants: [...e.participants, ...names] } : e));
  const removePart = (id, idx) => setUpcoming(upcoming.map(e => e.id === id ? { ...e, participants: e.participants.filter((_, i) => i !== idx) } : e));
  const completeRun = (id) => {
    const ev = upcoming.find(e => e.id === id);
    if (!ev) return;
    setUpcoming(upcoming.filter(e => e.id !== id));
    setPast([{ ...ev, id: "p" + Date.now(), photo: null, photo_hue: Math.floor(Math.random() * 360) }, ...past]);
  };
  const uploadPhoto = (id) => {
    setPast(past.map(p => p.id === id ? { ...p, photo: `https://picsum.photos/seed/${id}/600/400` } : p));
  };

  const sorted = [...upcoming].sort((a, b) => new Date(a.run_at) - new Date(b.run_at));

  return (
    <div style={{ position: "relative" }}>
      {tweaks.grain && <GrainOverlay/>}
      <Hero onNewRun={() => setCreateOpen(true)}/>

      <Section
        id="upcoming"
        number="01"
        kicker="THIS WEEK"
        title="UPCOMING RUNS"
        subtitle={`${sorted.length} runs on the board. Show up or add one.`}
        action={<button onClick={() => setCreateOpen(true)} style={bigBtn}>+ NEW RUN</button>}
      >
        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(420px, 1fr))",
          gap: 20,
        }}>
          {sorted.map((ev, i) => (
            <UpcomingCard
              key={ev.id} event={ev} index={i}
              onJoin={setJoinEvent}
              onComplete={completeRun}
              onRemove={removePart}
            />
          ))}
        </div>
      </Section>

      <Section
        id="past"
        number="02"
        kicker="IN THE BOOKS"
        title="PAST RUNS"
        subtitle="The archive. No deletes."
      >
        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))",
          gap: 20,
        }}>
          {past.map((ev, i) => (
            <PastCard key={ev.id} event={ev} index={i} onUpload={uploadPhoto}/>
          ))}
        </div>
      </Section>

      <Footer/>

      <CreateEventModal open={createOpen} onClose={() => setCreateOpen(false)} onCreate={addEvent}/>
      <JoinModal event={joinEvent} onClose={() => setJoinEvent(null)} onJoin={joinRun}/>

      <TweaksPanel tweaks={tweaks}>
        <TweakSection title="Accent">
          <TweakRadio label="Style" tweaks={tweaks} k="accent" options={[
            { value: "rainbow", label: "Rainbow" },
            { value: "mono", label: "Monochrome" },
          ]}/>
        </TweakSection>
        <TweakSection title="Atmosphere">
          <TweakToggle label="Grain overlay" tweaks={tweaks} k="grain"/>
        </TweakSection>
        <TweakSection title="Card style">
          <TweakRadio label="Shadow" tweaks={tweaks} k="cardStyle" options={[
            { value: "solid-shadow", label: "Solid shadow" },
            { value: "soft", label: "Soft shadow" },
            { value: "flat", label: "Flat" },
          ]}/>
        </TweakSection>
      </TweaksPanel>
    </div>
  );
}

function Section({ id, number, kicker, title, subtitle, action, children }) {
  return (
    <section id={id} style={{ padding: "96px 56px", position: "relative" }}>
      <div style={{
        display: "flex", alignItems: "flex-end",
        justifyContent: "space-between", gap: 24,
        marginBottom: 48, flexWrap: "wrap",
        borderBottom: "1.5px solid var(--ink)",
        paddingBottom: 24,
      }}>
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 12 }}>
            <div className="mono" style={{
              fontSize: 11, letterSpacing: "0.15em", fontWeight: 700,
              background: "var(--ink)", color: "var(--bg)",
              padding: "4px 10px", whiteSpace: "nowrap",
            }}>§ {number}</div>
            <div className="mono" style={{ fontSize: 11, letterSpacing: "0.15em", color: "var(--muted)" }}>
              {kicker}
            </div>
          </div>
          <h2 className="display" style={{ fontSize: "clamp(48px, 7vw, 96px)", margin: 0, letterSpacing: "-0.02em" }}>
            {title}
          </h2>
          <div style={{ fontSize: 16, color: "var(--muted)", marginTop: 10, maxWidth: 600 }}>
            {subtitle}
          </div>
        </div>
        {action}
      </div>
      {children}
    </section>
  );
}

function Footer() {
  return (
    <footer style={{
      background: "var(--ink)", color: "var(--bg)",
      padding: "64px 56px 32px", marginTop: 64,
      position: "relative", overflow: "hidden",
    }}>
      <div className="display" style={{
        fontSize: "clamp(80px, 14vw, 220px)",
        lineHeight: 0.85, letterSpacing: "-0.03em",
      }}>
        JUST<br/>RUN.
      </div>
      <div style={{
        display: "flex", justifyContent: "space-between",
        alignItems: "flex-end", marginTop: 48, flexWrap: "wrap", gap: 20,
      }}>
        <div className="mono" style={{ fontSize: 11, letterSpacing: "0.12em", opacity: 0.6 }}>
          SHIMODA RUNNING CLUB · EST 2024 · NO LOGIN · NO BS
        </div>
        <div className="mono" style={{ fontSize: 11, letterSpacing: "0.12em", opacity: 0.6 }}>
          MAY 31 · HALF MARATHON
        </div>
      </div>
    </footer>
  );
}

function GrainOverlay() {
  return (
    <div style={{
      position: "fixed", inset: 0, pointerEvents: "none", zIndex: 30,
      opacity: 0.06, mixBlendMode: "multiply",
      backgroundImage: `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='160' height='160'><filter id='n'><feTurbulence baseFrequency='0.9'/></filter><rect width='100%25' height='100%25' filter='url(%23n)'/></svg>")`,
    }}/>
  );
}

const bigBtn = {
  background: "var(--ink)", color: "var(--bg)",
  padding: "16px 24px", borderRadius: 999,
  fontWeight: 800, letterSpacing: "0.08em", fontSize: 13,
};

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
