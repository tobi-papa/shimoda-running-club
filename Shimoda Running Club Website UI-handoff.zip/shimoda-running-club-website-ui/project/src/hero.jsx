// Hero section — massive type with the runner, motion-reactive

function Hero({ onNewRun }) {
  const { pointer, velocity } = usePointer();
  const scroll = useScroll();
  const [now, setNow] = React.useState(new Date());
  React.useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  const countdown = (() => {
    const target = new Date("2026-05-31T07:00:00");
    const diff = target - now;
    const d = Math.max(0, Math.floor(diff / 86400000));
    const h = Math.max(0, Math.floor((diff % 86400000) / 3600000));
    const m = Math.max(0, Math.floor((diff % 3600000) / 60000));
    const s = Math.max(0, Math.floor((diff % 60000) / 1000));
    return { d, h, m, s };
  })();

  return (
    <section style={{
      position: "relative",
      padding: "96px 56px 64px",
      minHeight: "100vh",
      overflow: "hidden",
    }}>
      {/* header bar */}
      <div style={{
        display: "flex", justifyContent: "space-between", alignItems: "center",
        marginBottom: 48,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
          <div style={{
            width: 14, height: 14, borderRadius: 14,
            background: "linear-gradient(135deg,#ff2d55,#8e24ff,#3d5afe,#00c2a8)",
            animation: "spin 6s linear infinite",
          }}/>
          <div className="mono" style={{ fontSize: 13, letterSpacing: "0.08em", fontWeight: 700 }}>
            SHIMODA / RUN CLUB / EST. 2024
          </div>
        </div>
        <nav style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <MusicPlayer />
          <a href="#upcoming" className="mono" style={navStyle}>UPCOMING</a>
          <a href="#past" className="mono" style={navStyle}>PAST</a>
          <button onClick={onNewRun} style={ctaBtn}>
            <span>NEW RUN</span>
            <span style={{ marginLeft: 10 }}>↗</span>
          </button>
        </nav>
      </div>

      {/* Hero content grid */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "1.3fr 1fr",
        gap: 40,
        alignItems: "center",
        position: "relative",
        minHeight: "70vh",
      }}>
        {/* left: massive wordmark */}
        <div style={{ position: "relative", zIndex: 2 }}>
          <HeroWord scroll={scroll} pointer={pointer}/>
          <div style={{
            marginTop: 28, maxWidth: 520,
            display: "flex", flexDirection: "column", gap: 20,
          }}>
            <div style={{ fontSize: 22, fontWeight: 600, lineHeight: 1.25 }}>
              Welcome to the dorm's <span className="rainbow">running club</span>.
              Lace up, show up, run together — no login, just a shared board.
            </div>
            <div style={{ display: "flex", gap: 32, flexWrap: "wrap" }}>
              <Stat label="NEXT RACE" value="MAY 31"/>
              <Stat label="RUNNERS" value="24"/>
              <Stat label="KM THIS WEEK" value="312"/>
            </div>
          </div>
        </div>

        {/* right: runner + countdown */}
        <div style={{ position: "relative", height: 540 }}>
          <div style={{
            position: "absolute", right: -40, top: -20,
            transform: `translateY(${scroll * 0.12}px)`,
          }}>
            <Runner scroll={scroll} pointer={pointer} velocity={velocity} size={560}/>
          </div>
          {/* countdown chip */}
          <div style={{
            position: "absolute", left: -40, bottom: 0,
            background: "var(--ink)", color: "var(--bg)",
            padding: "18px 22px", borderRadius: 2,
            boxShadow: "0 24px 48px rgba(0,0,0,.18)",
            transform: `translateY(${scroll * -0.06}px)`,
          }}>
            <div className="mono" style={{ fontSize: 11, letterSpacing: "0.12em", opacity: 0.7 }}>HALF MARATHON STARTS IN</div>
            <div className="display" style={{ fontSize: 44, lineHeight: 1, marginTop: 6 }}>
              <Digit n={countdown.d}/>D <Digit n={countdown.h}/>H <Digit n={countdown.m}/>M <Digit n={countdown.s}/>S
            </div>
          </div>
        </div>
      </div>

      {/* bottom marquee */}
      <Marquee/>

      <style>{`
        @keyframes spin{to{transform:rotate(360deg)}}
      `}</style>
    </section>
  );
}

function HeroWord({ scroll, pointer }) {
  // Three big lines; each leans slightly based on pointer
  const px = (pointer.x - 0.5) * 10;
  const lines = ["SHIMODA", "RUNNING", "CLUB."];
  return (
    <h1 className="display" style={{
      fontSize: "clamp(80px, 11.5vw, 192px)",
      margin: 0,
      lineHeight: 0.85,
    }}>
      {lines.map((l, i) => (
        <div key={l} style={{
          overflow: "hidden",
          transform: `translateX(${px * (i === 1 ? 1.4 : 0.6)}px)`,
          transition: "transform .6s cubic-bezier(.2,.7,.2,1)",
        }}>
          <div style={{
            display: "inline-block",
            transform: `translateY(${Math.sin(scroll * 0.005 + i) * 3}px)`,
          }}>
            {l}
          </div>
        </div>
      ))}
    </h1>
  );
}

function Digit({ n }) {
  const [prev, setPrev] = React.useState(n);
  const [anim, setAnim] = React.useState(false);
  React.useEffect(() => {
    if (n !== prev) {
      setAnim(true);
      const id = setTimeout(() => { setPrev(n); setAnim(false); }, 300);
      return () => clearTimeout(id);
    }
  }, [n, prev]);
  return (
    <span style={{ display: "inline-block", animation: anim ? "tick .3s" : "none" }}>
      {String(n).padStart(2, "0")}
    </span>
  );
}

function Stat({ label, value }) {
  return (
    <div>
      <div className="mono" style={{ fontSize: 10, letterSpacing: "0.12em", color: "var(--muted)" }}>{label}</div>
      <div className="display" style={{ fontSize: 36, marginTop: 2 }}>{value}</div>
    </div>
  );
}

function Marquee() {
  const items = ["RUN TOGETHER", "★", "NO LOGIN", "★", "JUST RUN", "★", "MAY 31 HALF", "★", "SHOW UP", "★", "EASY PACE", "★"];
  const content = [...items, ...items, ...items];
  return (
    <div style={{
      position: "relative", marginTop: 72,
      borderTop: "1.5px solid var(--ink)", borderBottom: "1.5px solid var(--ink)",
      overflow: "hidden", padding: "18px 0",
      background: "var(--ink)", color: "var(--bg)",
    }}>
      <div style={{
        display: "flex", gap: 40, whiteSpace: "nowrap",
        animation: "marquee 40s linear infinite",
        width: "max-content",
      }}>
        {content.map((t, i) => (
          <span key={i} className="display" style={{ fontSize: 28 }}>{t}</span>
        ))}
      </div>
    </div>
  );
}

function MusicPlayer() {
  const [playing, setPlaying] = React.useState(true);
  const [muted, setMuted] = React.useState(true);
  const [bars, setBars] = React.useState([0.3, 0.6, 0.4, 0.8, 0.5]);

  React.useEffect(() => {
    if (!playing || muted) return;
    const id = setInterval(() => {
      setBars(() => Array.from({ length: 5 }, () => 0.25 + Math.random() * 0.75));
    }, 180);
    return () => clearInterval(id);
  }, [playing, muted]);

  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 10,
      border: "1.5px solid var(--ink)", padding: "6px 12px",
      borderRadius: 999, marginRight: 8,
    }}>
      <button onClick={() => setPlaying(p => !p)} title="play/pause" style={{ display: "flex", alignItems: "center" }}>
        {playing ? (
          <svg width="12" height="12" viewBox="0 0 12 12"><rect x="1" y="1" width="3" height="10" fill="currentColor"/><rect x="8" y="1" width="3" height="10" fill="currentColor"/></svg>
        ) : (
          <svg width="12" height="12" viewBox="0 0 12 12"><polygon points="2,1 11,6 2,11" fill="currentColor"/></svg>
        )}
      </button>
      <div style={{ display: "flex", alignItems: "end", gap: 2, height: 14 }}>
        {bars.map((b, i) => (
          <div key={i} style={{
            width: 2, height: `${(muted ? 0.15 : b) * 14}px`,
            background: "currentColor", transition: "height .18s",
          }}/>
        ))}
      </div>
      <div className="mono" style={{ fontSize: 10, letterSpacing: "0.1em" }}>
        {muted ? "MUTED" : "PLAYING"}
      </div>
      <button onClick={() => setMuted(m => !m)} title="mute" style={{ display: "flex", alignItems: "center" }}>
        {muted ? (
          <svg width="14" height="14" viewBox="0 0 14 14"><path d="M2 5v4h2l3 3V2L4 5H2z" fill="currentColor"/><line x1="9" y1="5" x2="13" y2="9" stroke="currentColor" strokeWidth="1.4"/><line x1="13" y1="5" x2="9" y2="9" stroke="currentColor" strokeWidth="1.4"/></svg>
        ) : (
          <svg width="14" height="14" viewBox="0 0 14 14"><path d="M2 5v4h2l3 3V2L4 5H2z" fill="currentColor"/><path d="M9 4 q2 3 0 6" stroke="currentColor" fill="none" strokeWidth="1.4"/><path d="M11 2 q3 5 0 10" stroke="currentColor" fill="none" strokeWidth="1.4"/></svg>
        )}
      </button>
    </div>
  );
}

const navStyle = {
  padding: "10px 14px",
  fontSize: 12,
  letterSpacing: "0.1em",
  fontWeight: 700,
  textDecoration: "none",
  color: "var(--ink)",
  borderRadius: 999,
};

const ctaBtn = {
  display: "inline-flex", alignItems: "center",
  background: "var(--ink)", color: "var(--bg)",
  padding: "14px 22px", borderRadius: 999,
  fontWeight: 800, letterSpacing: "0.08em", fontSize: 13,
};

Object.assign(window, { Hero, MusicPlayer });
