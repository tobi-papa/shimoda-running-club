// Abstract geometric "runner" that reacts to pointer + scroll.
// Built from angular polygons + trailing motion streaks. Original design.

function Runner({ scroll = 0, pointer = { x: 0.5, y: 0.5 }, velocity = 0, size = 520 }) {
  // scroll drives forward lean + stride
  // pointer.x nudges the position horizontally
  // velocity lengthens streaks
  const lean = Math.min(12, scroll * 0.015);
  const stride = Math.sin(scroll * 0.03) * 10;
  const shiftX = (pointer.x - 0.5) * 24;
  const shiftY = (pointer.y - 0.5) * 14;
  const streakLen = 60 + Math.min(140, velocity * 2);

  const streaks = [
    { y: 48, c: "#ff2d55", delay: 0 },
    { y: 90, c: "#ffb300", delay: 0.05 },
    { y: 132, c: "#00c2a8", delay: 0.1 },
    { y: 174, c: "#3d5afe", delay: 0.15 },
    { y: 216, c: "#8e24ff", delay: 0.2 },
    { y: 258, c: "#ff2d55", delay: 0.25 },
    { y: 300, c: "#ffb300", delay: 0.3 },
    { y: 342, c: "#00c2a8", delay: 0.35 },
  ];

  return (
    <div style={{
      position: "relative",
      width: size,
      height: size * 0.95,
      transform: `translate(${shiftX}px, ${shiftY}px)`,
      transition: "transform .4s cubic-bezier(.2,.7,.2,1)",
      willChange: "transform",
    }}>
      {/* streaks behind the figure */}
      <div style={{ position: "absolute", inset: 0, pointerEvents: "none" }}>
        {streaks.map((s, i) => (
          <div key={i} style={{
            position: "absolute",
            left: 0,
            top: s.y,
            height: 6,
            width: streakLen + i * 8,
            background: `linear-gradient(90deg, transparent, ${s.c})`,
            borderRadius: 6,
            opacity: 0.85,
            transform: `translateX(${-velocity * 0.4 - i * 3}px)`,
            transition: `width .25s cubic-bezier(.2,.7,.2,1) ${s.delay}s, transform .25s`,
          }}/>
        ))}
      </div>

      {/* the runner — angular facets built from SVG polygons */}
      <svg
        viewBox="0 0 520 500"
        width={size}
        height={size * 0.95}
        style={{
          position: "absolute",
          inset: 0,
          transform: `rotate(${-lean * 0.4}deg) translateY(${stride}px)`,
          transition: "transform .6s cubic-bezier(.2,.7,.2,1)",
          filter: "drop-shadow(0 30px 30px rgba(0,0,0,.12))",
        }}
      >
        <defs>
          <linearGradient id="body" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#ff2d55"/>
            <stop offset="35%" stopColor="#8e24ff"/>
            <stop offset="70%" stopColor="#3d5afe"/>
            <stop offset="100%" stopColor="#00c2a8"/>
          </linearGradient>
          <linearGradient id="limb" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#ffb300"/>
            <stop offset="100%" stopColor="#ff2d55"/>
          </linearGradient>
          <linearGradient id="leg" x1="0" y1="1" x2="0" y2="0">
            <stop offset="0%" stopColor="#00c2a8"/>
            <stop offset="100%" stopColor="#3d5afe"/>
          </linearGradient>
        </defs>

        {/* back leg trailing */}
        <polygon points="120,360 180,300 240,340 220,420 150,440" fill="url(#leg)" opacity="0.85"/>
        <polygon points="150,440 220,420 260,470 200,490" fill="#0b0b0c"/>

        {/* torso — multiple facets */}
        <polygon points="200,150 320,130 360,260 280,300 220,270" fill="url(#body)"/>
        <polygon points="220,270 280,300 300,360 240,380" fill="#8e24ff" opacity="0.9"/>
        <polygon points="280,300 360,260 380,340 300,360" fill="#3d5afe" opacity="0.85"/>

        {/* head */}
        <polygon points="300,70 360,60 380,130 340,150 290,130" fill="url(#body)"/>
        <polygon points="340,150 380,130 400,180 360,200" fill="#ff2d55" opacity="0.9"/>

        {/* front arm punching forward */}
        <polygon points="360,180 440,140 470,170 420,220 370,220" fill="url(#limb)"/>
        <polygon points="420,220 470,170 490,200 460,240" fill="#ffb300"/>

        {/* back arm bent */}
        <polygon points="220,170 170,210 180,260 230,240" fill="#ff2d55" opacity="0.9"/>

        {/* front leg driving up */}
        <polygon points="280,340 340,380 360,460 310,480 280,430" fill="url(#leg)"/>
        <polygon points="310,480 360,460 380,490 330,500" fill="#0b0b0c"/>

        {/* neckline accent */}
        <polygon points="290,130 340,150 320,180 280,160" fill="#0b0b0c" opacity="0.8"/>

        {/* shatter shards (motion fragments flying off back) */}
        <polygon points="60,180 90,170 80,210 50,220" fill="#ff2d55" opacity="0.9"/>
        <polygon points="30,240 70,230 60,270 20,280" fill="#ffb300" opacity="0.85"/>
        <polygon points="80,300 110,295 100,330 70,340" fill="#00c2a8" opacity="0.9"/>
        <polygon points="10,350 50,345 40,380 5,390" fill="#3d5afe" opacity="0.85"/>
        <polygon points="100,80 130,90 115,120 95,110" fill="#8e24ff" opacity="0.85"/>
      </svg>
    </div>
  );
}

// hook that tracks pointer position (normalized 0..1) and velocity
function usePointer() {
  const [p, setP] = React.useState({ x: 0.5, y: 0.5 });
  const [v, setV] = React.useState(0);
  const last = React.useRef({ x: 0, y: 0, t: Date.now() });
  React.useEffect(() => {
    const handler = (e) => {
      const nx = e.clientX / window.innerWidth;
      const ny = e.clientY / window.innerHeight;
      const now = Date.now();
      const dt = Math.max(16, now - last.current.t);
      const dx = e.clientX - last.current.x;
      const dy = e.clientY - last.current.y;
      const vel = Math.sqrt(dx*dx + dy*dy) / dt * 1000;
      last.current = { x: e.clientX, y: e.clientY, t: now };
      setP({ x: nx, y: ny });
      setV(Math.min(200, vel * 0.12));
    };
    window.addEventListener("mousemove", handler);
    return () => window.removeEventListener("mousemove", handler);
  }, []);
  // decay velocity
  React.useEffect(() => {
    const id = setInterval(() => setV((v) => v * 0.85), 80);
    return () => clearInterval(id);
  }, []);
  return { pointer: p, velocity: v };
}

function useScroll() {
  const [y, setY] = React.useState(0);
  React.useEffect(() => {
    const h = () => setY(window.scrollY);
    window.addEventListener("scroll", h, { passive: true });
    return () => window.removeEventListener("scroll", h);
  }, []);
  return y;
}

Object.assign(window, { Runner, usePointer, useScroll });
