// Event cards — upcoming + past

function UpcomingCard({ event, onJoin, onComplete, onRemove, index }) {
  const d = fmtDate(event.run_at);
  const [hover, setHover] = React.useState(false);
  const [tilt, setTilt] = React.useState({ x: 0, y: 0 });

  const onMove = (e) => {
    const r = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - r.left) / r.width - 0.5) * 8;
    const y = ((e.clientY - r.top) / r.height - 0.5) * -8;
    setTilt({ x, y });
  };

  return (
    <div
      className="reveal hover-lift"
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => { setHover(false); setTilt({ x: 0, y: 0 }); }}
      onMouseMove={onMove}
      style={{
        position: "relative",
        background: "var(--paper)",
        border: "1.5px solid var(--ink)",
        borderRadius: 4,
        padding: 28,
        transform: `perspective(900px) rotateY(${tilt.x}deg) rotateX(${tilt.y}deg)`,
        transition: "transform .25s cubic-bezier(.2,.7,.2,1), box-shadow .25s",
        boxShadow: hover ? "10px 14px 0 var(--ink)" : "4px 6px 0 var(--ink)",
        overflow: "hidden",
      }}
    >
      {/* corner index */}
      <div className="mono" style={{
        position: "absolute", top: 14, right: 18,
        fontSize: 11, letterSpacing: "0.1em", color: "var(--muted)",
      }}>
        RUN № {String(index + 1).padStart(3, "0")}
      </div>

      {/* hover accent streak */}
      <div style={{
        position: "absolute", top: 0, left: 0, right: 0, height: 4,
        background: "linear-gradient(90deg,#ff2d55,#ffb300,#00c2a8,#3d5afe,#8e24ff)",
        transform: hover ? "scaleX(1)" : "scaleX(0)",
        transformOrigin: "left",
        transition: "transform .5s cubic-bezier(.2,.7,.2,1)",
      }}/>

      {/* date block */}
      <div style={{ display: "flex", gap: 20, alignItems: "flex-start", marginBottom: 20 }}>
        <div style={{
          border: "1.5px solid var(--ink)",
          padding: "10px 14px", minWidth: 96, textAlign: "center",
          background: hover ? "var(--ink)" : "transparent",
          color: hover ? "var(--bg)" : "var(--ink)",
          transition: "background .3s, color .3s",
        }}>
          <div className="mono" style={{ fontSize: 10, letterSpacing: "0.12em" }}>{d.day}</div>
          <div className="display" style={{ fontSize: 40, lineHeight: 1, margin: "4px 0" }}>{d.dd}</div>
          <div className="mono" style={{ fontSize: 10, letterSpacing: "0.12em" }}>{d.mon}</div>
        </div>
        <div style={{ flex: 1, paddingTop: 4 }}>
          <div className="mono" style={{ fontSize: 11, letterSpacing: "0.1em", color: "var(--muted)" }}>
            {d.hh}:{d.mm} · {timeUntil(event.run_at)}
          </div>
          <div className="display" style={{ fontSize: 26, marginTop: 6, letterSpacing: "-0.02em" }}>
            {event.distance_km} KM · {event.pace}/KM
          </div>
          <div style={{ fontSize: 14, color: "var(--muted)", marginTop: 4 }}>
            📍 {event.meeting_point}
          </div>
        </div>
      </div>

      {/* notes */}
      {event.notes && (
        <div style={{
          fontSize: 14, lineHeight: 1.5, color: "var(--ink-2)",
          padding: "14px 16px", background: "rgba(11,11,12,.04)",
          borderLeft: "3px solid var(--ink)", marginBottom: 18,
        }}>
          {event.notes}
        </div>
      )}

      {/* participants */}
      <div style={{ marginBottom: 20 }}>
        <div className="mono" style={{ fontSize: 10, letterSpacing: "0.12em", color: "var(--muted)", marginBottom: 8 }}>
          PARTICIPANTS · {event.participants.length}
        </div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
          {event.participants.map((p, i) => (
            <ParticipantChip key={i} name={p} onRemove={() => onRemove(event.id, i)} />
          ))}
        </div>
      </div>

      {/* actions */}
      <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
        <button onClick={() => onJoin(event)} style={{
          background: "var(--ink)", color: "var(--bg)",
          padding: "12px 20px", borderRadius: 999,
          fontWeight: 800, letterSpacing: "0.08em", fontSize: 12,
          display: "inline-flex", alignItems: "center", gap: 8,
        }}>
          JOIN RUN <span>→</span>
        </button>
        <button onClick={() => onComplete(event.id)} style={{
          border: "1.5px solid var(--ink)",
          padding: "10px 18px", borderRadius: 999,
          fontWeight: 700, letterSpacing: "0.06em", fontSize: 12,
        }}>
          COMPLETE
        </button>
        {event.strava_url && (
          <a href={event.strava_url} target="_blank" rel="noreferrer" className="mono" style={{
            fontSize: 11, letterSpacing: "0.1em", textDecoration: "underline",
            marginLeft: "auto", color: "var(--ink)",
          }}>
            STRAVA ROUTE ↗
          </a>
        )}
      </div>

      <div className="mono" style={{ fontSize: 10, letterSpacing: "0.1em", color: "var(--muted)", marginTop: 14 }}>
        CREATED BY {event.creator.toUpperCase()}
      </div>
    </div>
  );
}

function ParticipantChip({ name, onRemove }) {
  const [hover, setHover] = React.useState(false);
  return (
    <div
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: "inline-flex", alignItems: "center", gap: 6,
        padding: "5px 10px 5px 10px",
        background: hover ? "var(--ink)" : "rgba(11,11,12,.06)",
        color: hover ? "var(--bg)" : "var(--ink)",
        borderRadius: 999, fontSize: 12, fontWeight: 600,
        transition: "all .2s",
      }}
    >
      {name}
      <button onClick={onRemove} title="remove" style={{
        width: 16, height: 16, borderRadius: 999,
        display: "flex", alignItems: "center", justifyContent: "center",
        background: hover ? "var(--bg)" : "transparent",
        color: hover ? "var(--ink)" : "var(--muted)",
        fontSize: 10, lineHeight: 1, fontWeight: 700,
      }}>×</button>
    </div>
  );
}

function PastCard({ event, onUpload, index }) {
  const d = fmtDate(event.run_at);
  const [hover, setHover] = React.useState(false);
  return (
    <div
      className="reveal"
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        background: "var(--paper)",
        border: "1.5px solid var(--ink)",
        overflow: "hidden",
        transform: hover ? "translateY(-4px)" : "none",
        transition: "transform .35s",
        boxShadow: hover ? "8px 10px 0 var(--ink)" : "4px 6px 0 var(--ink)",
      }}
    >
      {/* photo / placeholder */}
      <div style={{
        position: "relative",
        height: 200,
        background: event.photo
          ? `url(${event.photo}) center/cover`
          : `linear-gradient(135deg, hsl(${event.photo_hue} 75% 60%), hsl(${(event.photo_hue+60)%360} 75% 55%))`,
        overflow: "hidden",
      }}>
        {!event.photo && (
          <>
            {/* stripe pattern */}
            <div style={{
              position: "absolute", inset: 0,
              backgroundImage: "repeating-linear-gradient(45deg, transparent 0 12px, rgba(255,255,255,.18) 12px 14px)",
            }}/>
            <div style={{
              position: "absolute", inset: 0,
              display: "flex", alignItems: "center", justifyContent: "center",
            }}>
              <div className="mono" style={{ color: "#fff", fontSize: 11, letterSpacing: "0.15em", opacity: 0.9 }}>
                [ PHOTO ]
              </div>
            </div>
            <button onClick={() => onUpload(event.id)} style={{
              position: "absolute", bottom: 12, right: 12,
              background: "#fff", color: "var(--ink)",
              padding: "8px 14px", borderRadius: 999,
              fontSize: 11, fontWeight: 800, letterSpacing: "0.08em",
              opacity: hover ? 1 : 0, transform: hover ? "translateY(0)" : "translateY(8px)",
              transition: "all .3s",
            }}>UPLOAD PHOTO ↑</button>
          </>
        )}
        <div style={{
          position: "absolute", top: 12, left: 12,
          background: "var(--ink)", color: "var(--bg)",
          padding: "6px 10px",
          fontFamily: "'JetBrains Mono',monospace",
          fontSize: 10, letterSpacing: "0.12em", fontWeight: 700,
          whiteSpace: "nowrap",
        }}>
          ✓ COMPLETED · {d.mon} {d.dd}
        </div>
      </div>
      {/* content */}
      <div style={{ padding: 20 }}>
        <div className="display" style={{ fontSize: 22, lineHeight: 1, marginBottom: 6 }}>
          {event.distance_km} KM
        </div>
        <div className="mono" style={{ fontSize: 11, letterSpacing: "0.1em", color: "var(--muted)" }}>
          {event.pace}/KM · {event.participants.length} RUNNERS
        </div>
        {event.notes && (
          <div style={{ fontSize: 13, marginTop: 10, color: "var(--ink-2)", lineHeight: 1.5 }}>
            {event.notes}
          </div>
        )}
        <div style={{ display: "flex", flexWrap: "wrap", gap: 4, marginTop: 12 }}>
          {event.participants.map((p, i) => (
            <span key={i} style={{
              fontSize: 11, padding: "3px 8px",
              background: "rgba(11,11,12,.06)", borderRadius: 999,
              fontWeight: 600,
            }}>{p}</span>
          ))}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { UpcomingCard, PastCard });
